| delta dental ppo (point-of-service)                                                 | in network                 | unnamed: 2                   | out of network           | waiting periods   |
|-------------------------------------------------------------------------------------|----------------------------|------------------------------|--------------------------|-------------------|
|                                                                                     | Delta Dental PPOTM dentist | Delta Dental Premier dentist | Nonparticipating dentist |                   |
|                                                                                     | Plan pays                  | Plan pays                    | Plan pays                |                   |
| DIAGNOSTIC AND PREVENTIVE SERVICES                                                  |                            |                              |                          |                   |
| Diagnostic and preventive services-exams, cleanings, fluoride and space maintainers | 100%                       | 100%                         | 100%                     | None              |
| Emergency palliative treatment-to temporarily relieve pain                          | 100%                       | 100%                         | 100%                     | None              |
| Radiographs-X-rays                                                                  | 100%                       | 100%                         | 100%                     | None              |
| Sealants-to prevent decay of permanent teeth                                        | 100%                       | 100%                         | 100%                     | None              |
| BASIC SERVICES                                                                      |                            |                              |                          |                   |
| Minor restorative services-fillings and crown repair                                | 80%                        | 60%                          | 60%                      | None              |
| Oral surgery services-extractions and dental surgery                                | 80%                        | 60%                          | 60%                      | None              |
| Endodontic services—root canals                                                     | 80%                        | 60%                          | 60%                      | None              |
| Periodontic services-to treat gum disease                                           | 80%                        | 60%                          | 60%                      | None              |
| Relines and repairs-prosthetic appliances                                           | 80%                        | 60%                          | 60%                      | None              |
| Other basic services-miscellaneous services                                         | 80%                        | 60%                          | 60%                      | None              |
| MAJOR SERVICES                                                                      |                            |                              |                          |                   |
| Prosthodontic services-bridges, dentures and crowns over implants                   | 50%                        | 50%                          | 50%                      | None              |
| Major restorative services—crowns                                                   | 50%                        | 50%                          | 50%                      | None              |
| ORTHODONTIC SERVICES                                                                |                            |                              |                          |                   |
| Orthodontic services-medically necessary                                            | 50%                        | 50%                          | 50%                      | None              |
