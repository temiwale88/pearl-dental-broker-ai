| Plan Summary                                                            | Advantage Network              | Premier Network   | Out-of-Network   |
|-------------------------------------------------------------------------|--------------------------------|-------------------|------------------|
| Services                                                                |                                |                   |                  |
| PreventiveOral Exams, Cleanings, Sealants, X-rays, Fluoride             | 100%                           | 100%              | 100% up to MAC*  |
| BasicFillings, Space Maintainers, Oral Surgery                          | 80%                            | 80%               | 80% up to MAC*   |
| MajorCrowns, Bridges, Prosthodontics, Endodontics, Periodontics         | 50%                            | 50%               | 50% up to MAC*   |
| Orthodontics (up to age 19**)                                           | 50%                            | 50%               | 50%              |
| Waiting Periods                                                         |                                |                   |                  |
| Preventive                                                              | None                           |                   |                  |
| Basic (age 19 and older)                                                | 6 Month Waiting Period         |                   |                  |
| Major (age 19 and older)                                                | 15 Month Waiting Period        |                   |                  |
| Orthodontics(Medically Necessary / Non-Medically Necessary)             | None / 24 Month Waiting Period |                   |                  |
| Deductible (applies to Preventive, Basic and Major)                     |                                |                   |                  |
| Individual                                                              | $25                            |                   |                  |
| Family Max                                                              | $75                            |                   |                  |
| Maximums                                                                |                                |                   |                  |
| Major Annual Max (age 19 and older)                                     | $750                           |                   |                  |
| Annual Max per Person (age 19 and older)                                | $1,500                         | $1,000            |                  |
| Orthodontic Lifetime Max(Medically Necessary / Non-Medically Necessary) | No Maximum / $1,000            |                   |                  |
| Pediatric EHB Annual Max                                                | No Maximum                     |                   |                  |
| Pedriatric Individual EHB Out-of-Pocket Max                             | $375                           |                   |                  |
| Pediatric Family EHB Out-of-Pocket Max                                  | $750                           |                   |                  |
