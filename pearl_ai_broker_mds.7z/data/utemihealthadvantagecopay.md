| Plan Summary                                                    | Advantage Network       | Out-of-Network             |
|-----------------------------------------------------------------|-------------------------|----------------------------|
| Services                                                        |                         |                            |
| PreventiveOral Exams, Cleanings, Sealants, X-rays, Fluoride     | 100%                    | See Claim Payment Schedule |
| BasicFillings, Space Maintainers, Oral Surgery                  | See Co-Pay Schedule     |                            |
| MajorCrowns, Bridges, Prosthodontics, Endodontics, Periodontics |                         |                            |
| OrthodonticsChildren (age 7 through 18)                         | Discount Only           | No Coverage                |
| Adults                                                          | Discount Only           | No Coverage                |
| Waiting Periods                                                 |                         |                            |
| Preventive                                                      | None                    |                            |
| Basic                                                           | 6 Month Waiting Period  |                            |
| Major                                                           | 12 Month Waiting Period |                            |
| Orthodontics                                                    | Not Applicable          |                            |
| Deductible (applies to Preventive, Basic and Major)             |                         |                            |
| Individual                                                      | $50                     |                            |
| Family Max                                                      | $150                    |                            |
| Maximums                                                        |                         |                            |
| Major Annual Max                                                | No Maximum              |                            |
| Annual Max per Person                                           | No Maximum              |                            |
| Orthodontic Lifetime Max                                        | Not Applicable          |                            |
| Pediatric EHB Annual Max                                        | None                    |                            |
| Pedriatric Individual EHB Out-of-Pocket Max                     | $375                    |                            |
| Pediatric Family EHB Out-of-Pocket Max                          | $750                    |                            |
