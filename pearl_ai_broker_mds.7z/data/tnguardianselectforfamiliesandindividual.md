| PPO                               | PPO                                                           | PPO                                               |
|-----------------------------------|---------------------------------------------------------------|---------------------------------------------------|
| Preventive Plus for Families and
Individuals                                   | Select for Families and Individuals                           | Basics for Families and Individuals               |
| Plan Summary Schedule of Benefits | Plan Summary Schedule of Benefits                             | Plan Summary Schedule of Benefits                 |
| ✓ A PPO Plan for families that provides coverage for
preventive and basic services .                                   | A comprehensive family plan , including adults and children . | ✓ A family plan , including adults and children . |
| ✓ Get most preventive services , such as oral exams ,
cleanings , and X - rays at 100 % once the annual deductible                                   | ✓ You are responsible for a percent of the total billed
( coinsurance ) .                                                               | ✓ You are responsible for a percent of the total billed
( coinsurance ) .                                                   |
| has been reached .                | ✓ Get most preventive services , such as oral exams ,
cleanings , and X - rays at 100 % once the annual deductible .
has been reached .                                                               | ✓ Get most preventive services , such as oral exams ,
cleanings , and X - rays at 100 % once the annual deductible
has been reached .                                                   |
| Annual Maximum $ 1000             | Annual Maximum $ 800                                          | Annual Maximum $ 1500                             |
| Deductibles FROM $ 50             | Deductibles FROM $ 50                                         | Deductibles FROM $ 50                             |
| View Details                      | View Details                                                  | View Details                                      |
