| PPO                                                             | PPO                                               | PPO                              |
|-----------------------------------------------------------------|---------------------------------------------------|----------------------------------|
| Essentials for Families and Individuals                         | Basics for Families and Individuals               | Preventive Plus for Families and
Individuals                                  |
| Plan Summary Schedule of Benefits                               | Plan SummarySchedule of Benefits                  | Plan SummarySchedule of Benefits |
| ✓ A comprehensive family plan , including adults and children . | ✓ A family plan , including adults and children . | ✓ A PPO Plan for families that provides coverage for
preventive and basic services .                                  |
| You are responsible for a percent of the total billed
( coinsurance ) .                                                                 | ✓ You are responsible for a percent of the total billed
( coinsurance ) .                                                   | ✓ Get most preventive services , such as oral exams ,
cleanings , and X - rays at 100 % once the annual dedu                                  |
| Get most preventive services , such as oral exams ,
cleanings , and X - rays at 100 % once the annual deductible
has been reached .                                                                 | ✓ Get most preventive services , such as oral exams ,
cleanings , and X - rays at 100 % once the annual deductible
has been reached .                                                   | has been reached .               |
| Annual Maximum $ 1000                                           | Annual Maximum $ 1500                             | Annual Maximum                   |
