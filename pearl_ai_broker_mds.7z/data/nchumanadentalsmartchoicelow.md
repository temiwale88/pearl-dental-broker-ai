| Class I - Diagnostic and Preventive                |         |         |
|----------------------------------------------------|---------|---------|
| Routine oral examinations ( limit two per year ) ● |         |         |
| Periodontal examinations ( limit two per year ) .  | Adult - | Adult - |
| • Bitewing X - rays ( limit two sets per year , excludes full
mouth and panoramic )                                                    | 100 % no deductible
No waiting period         | 70 % after deductible
No waiting period         |
| Cleanings ( limit two per year )                   |         |         |
| Topical fluoride treatment ( limit two per year , age 19 and
under ) ( topical fluoride varnish ages 0-5 , 100 % no
deductible                                                    | Children -
100 % after deductible
No waiting period         | Children -
50 % after deductible
No waiting period         |
| Sealants ( limit one per tooth per three years , age 19 and
under )
●                                                    |         |         |
