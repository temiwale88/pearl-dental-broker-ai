| CERTIFIED HIGH   | PLANS PAY    |    | CERTIFIED LOW   | PLANS PAY    |
|------------------|--------------|----|-----------------|--------------|
| ADULT OR FAMILY
In - Network / Out - of - Network                  | PEDIATRIC " EHB "
In - Network / Out - of - Network              |    | ADULT OR FAMILY
In - Network / Out - of - Network                 | PEDIATRIC " EHB "
In - Network / Out - of - Network              |
| $                | $            |    | $               | $            |
| 100 % / 80 %     | 100 % / 80 % |    | 100 % / 70 %    | 100 % / 70 % |
| 100 % / 80 %     | 100 % / 80 % |    | 100 % / 70 %    | 100 % / 70 % |
| 100 % / 80 %     | 100 % / 80 % |    | 100 % / 70 %
Waiting Period : 6 Months                 | 100 % / 70 % |
| 75 % / 60 %
Waiting Period : 6 Months                  | 75 % / 60 %  |    | 60 % / 40 %
Waiting Period : 6 Months                 | 60 % / 40 %  |
| 75 % / 60 %
Waiting Period : 12 Months                  | 75 % / 60 %  |    | 60 % / 40 %
Waiting Period : 12 Months                 | 60 % / 40 %  |
| 50 % / 40 %
Waiting Period : 12 Months                  | 50 % / 40 %  |    | 50 % / 30 %
Waiting Period : 12 Months                 | 50 % / 30 %  |
| Not Covered      | 50 % / 50 %  |    | Not Covered     | 50 % / 50 %  |
| $ 50 / $ 150     | $ 50 / $ 150 |    | $ 50 / $ 150    | $ 50 / $ 150 |
