| PPO                                                             | DHMO                                           | PPO                                               | PPO   | PPO                                                             |
|-----------------------------------------------------------------|------------------------------------------------|---------------------------------------------------|-------|-----------------------------------------------------------------|
| Essentials for Families and Individuals                         | Managed DentalGuard                            | Basics for Families and Individuals               | Preventive Plus for Families and
Individuals       | Choice for Families and Individuals                             |
| Plan Summary Schedule of Benefits
Sumario Detalles del Plan                                                                 | Plan SummarySchedule of Benefits
Sumario Detalles del Plan                                                | Plan SummarySchedule of Benefits
Sumario Detalles del Plan                                                   | Plan Summary Schedule of Benefits
Sumario Detalles del Plan       | Plan Summary Schedule of Benefits
Sumario Detalles del Plan                                                                 |
| ✓ A comprehensive family plan , including adults and children . | ✓ A DHMO copay plan .                          | ✓ A family plan , including adults and children . | ✓A PPO Plan for families that provides coverage for
preventive and basic services .       | ✓ A comprehensive family plan , including adults and children . |
| ✓ You are responsible for a percent of the total billed
( coinsurance ) .                                                                 | ✓ Includes Pediatric Essential Health Benefits | ✓ You are responsible for a percent of the total billed
( coinsurance ) .                                                   | ✓ Get most preventive services , such as oral exams ,
cleanings , and X - rays at 100 % once the annual deductible
has been reached .       | ✓ You are responsible for a percent of the total billed
( coinsurance ) .                                                                 |
| ✓ Get most preventive services , such as oral exams ,
cleanings , and X - rays at 100 % once the annual deductible
has been reached .                                                                 | ✓ A comprehensive adult and child plan .
✓ Covers standard or medically necessity orthodontic
coverage .                                                | ✓ Get most preventive services , such as oral exams ,
cleanings , and X - rays at 100 % once the annual deductible
has been reached .                                                   |       | ✓ Get most preventive services , such as oral exams ,
cleanings , and X - rays at 100 % once the annual deductible
has been reached .                                                                 |
| Annual Maximum $ 1000                                           |                                                | Annual Maximum $ 1500                             | nan   | nan                                                             |
| Deductibles FROM $ 60                                           |                                                | Deductibles FROM $ 60                             | nan   | nan                                                             |
| View Details                                                    | View Details                                   | View Details                                      | nan   | nan                                                             |
