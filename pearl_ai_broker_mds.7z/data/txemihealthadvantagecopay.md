| Plan Summary                                                            | Advantage Network              | Out-of-Network      |
|-------------------------------------------------------------------------|--------------------------------|---------------------|
| Services                                                                |                                |                     |
| PreventiveOral Exams, Cleanings, Sealants, X-rays, Fluoride             | 100%                           | 100% up to MAC*     |
| BasicFillings, Space Maintainers, Oral Surgery                          | See Co-Pay Schedule            | See Co-Pay Schedule |
| MajorCrowns, Bridges, Prosthodontics, Endodontics, Periodontics         |                                |                     |
| Orthodontics (up to age 19**)                                           | 50%                            | 50%                 |
| Waiting Periods                                                         |                                |                     |
| Preventive                                                              | None                           |                     |
| Basic (age 19 and older)                                                | 6 Month Waiting Period         |                     |
| Major (age 19 and older)                                                | 12 Month Waiting Period        |                     |
| Orthodontics(Medically Necessary / Non-Medically Necessary)             | None / 24 Month Waiting Period |                     |
| Deductible (applies to Preventive, Basic and Major)                     |                                |                     |
| Individual                                                              | $50                            |                     |
| Family Max                                                              | $150                           |                     |
| Maximums                                                                |                                |                     |
| Major Annual Max                                                        | No Maximum                     |                     |
| Annual Max per Person                                                   | No Maximum                     |                     |
| Orthodontic Lifetime Max(Medically Necessary / Non-Medically Necessary) | No Maximum / $1,000            |                     |
| Pediatric EHB Annual Max                                                | No Maximum                     |                     |
| Pedriatric Individual EHB Out-of-Pocket Max                             | $375                           |                     |
| Pediatric Family EHB Out-of-Pocket Max                                  | $750                           |                     |
