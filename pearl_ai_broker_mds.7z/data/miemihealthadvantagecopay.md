| Plan Summary                                                    | Advantage Network       | Out-of-Network      |
|-----------------------------------------------------------------|-------------------------|---------------------|
| Services                                                        |                         |                     |
| PreventiveOral Exams, Cleanings, Sealants, X-rays, Fluoride     | 100%                    | See Co-Pay Schedule |
| BasicFillings, Space Maintainers, Oral Surgery                  | See Co-Pay Schedule     |                     |
| MajorCrowns, Bridges, Prosthodontics, Endodontics, Periodontics |                         |                     |
| Orthodontics (Children age 7 through 18)                        | Discount Only           | Not Covered         |
| Orthodontics (Adults)                                           | Discount Only           | Not Covered         |
| Waiting Periods                                                 |                         |                     |
| Preventive                                                      | None                    |                     |
| Basic (age 19 and older)                                        | 6 Month Waiting Period  |                     |
| Major (age 19 and older)                                        | 12 Month Waiting Period |                     |
| Orthodontics                                                    | Not Applicable          |                     |
| Deductible (applies to Preventive, Basic and Major)             |                         |                     |
| Individual                                                      | $50                     |                     |
| Family Max                                                      | $150                    |                     |
| Maximums                                                        |                         |                     |
| Major Annual Max                                                | No Maximum              |                     |
| Annual Max per Person                                           | No Maximum              |                     |
| Orthodontic Lifetime Max                                        | Not Applicable          |                     |
| Pediatric EHB Annual Max                                        | No Maximum              |                     |
| Pedriatric Individual EHB Out-of-Pocket Max                     | $375                    |                     |
| Pediatric Family EHB Out-of-Pocket Max                          | $750                    |                     |
