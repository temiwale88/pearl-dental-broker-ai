| Plan Summary                                                    | Premier Network         | Out-of-Network   |
|-----------------------------------------------------------------|-------------------------|------------------|
| Services                                                        |                         |                  |
| PreventiveOral Exams, Cleanings, Sealants, X-rays, Fluoride     | 100%                    | 80% up to MAC*   |
| BasicFillings, Space Maintainers, Oral Surgery                  | 60%                     | 50% up to MAC*   |
| MajorCrowns, Bridges, Prosthodontics, Endodontics, Periodontics | 40%                     | 30% up to MAC*   |
| Orthodontics (Children age 7 through 18)                        | Discount Only           | Not Covered      |
| Orthodontics (Adults)                                           | Discount Only           | Not Covered      |
| Waiting Periods                                                 |                         |                  |
| Preventive                                                      | None                    |                  |
| Basic (age 19 and older)                                        | 6 Month Waiting Period  |                  |
| Major (age 19 and older)                                        | 18 Month Waiting Period |                  |
| Orthodontics                                                    | Not Applicable          |                  |
| Deductible (applies to Preventive, Basic and Major)             |                         |                  |
| Individual                                                      | $100                    |                  |
| Family Max                                                      | $300                    |                  |
| Maximums                                                        |                         |                  |
| Major Annual Max (age 19 and older)                             | $500                    |                  |
| Annual Max per Person (age 19 and older)                        | $1,000                  |                  |
| Orthodontic Lifetime Max                                        | Not Applicable          |                  |
| Pediatric EHB Annual Max                                        | No Maximum              |                  |
| Pedriatric Individual EHB Out-of-Pocket Max                     | $375                    |                  |
| Pediatric Family EHB Out-of-Pocket Max                          | $750                    |                  |
