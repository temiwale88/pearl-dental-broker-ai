| SmartSmile - EC                            | Monthly   | Super SmartSmile - EC                      | SmartSmile Plus - EC                       |
|--------------------------------------------|-----------|--------------------------------------------|--------------------------------------------|
| Adult                                      | $ 20.00   | nan                                        | nan                                        |
| Young Adult ( 19-25 years old )            | $ 17.50   | nan                                        | nan                                        |
| Pediatric Child * ( 18 years old & under ) | $ 26.50   | nan                                        | nan                                        |
| nan                                        | $ 28.25   | Adult                                      | nan                                        |
| nan                                        | $ 23.25   | Young Adult ( 19-25 years old )            | nan                                        |
| nan                                        | $ 26.50   | Pediatric Child * ( 18 years old & under ) | nan                                        |
| nan                                        | $ 28.25   | nan                                        | Adult                                      |
| nan                                        | $ 24.50   | nan                                        | Young Adult ( 19-25 years old )            |
| nan                                        | $ 29.25   | nan                                        | Pediatric Child * ( 18 years old & under ) |
