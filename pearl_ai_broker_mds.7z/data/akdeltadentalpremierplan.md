| delta dental premier              | age 0-18, members pay                                  | age 19+, members pay   |
|-----------------------------------|--------------------------------------------------------|------------------------|
| Calendar year costs               |                                                        |                        |
| Deductible per person             | $0                                                     |                        |
| Out-of-pocket maximum (ages 0-18) | $375 for one member / $750 for two or more members     |                        |
| Annual maximum (ages 19+)         | $1,100                                                 |                        |
| Class 1                           |                                                        |                        |
| Exams and X-rays                  | 30%                                                    | 20%                    |
| Cleanings                         | 30%                                                    | 20%                    |
| Periodontal maintenance           | 30%                                                    | 20%                    |
| Sealants                          | 30%                                                    | 20%                    |
| Topical fluoride                  | 30%                                                    | 20%                    |
| Class 2                           |                                                        |                        |
| Space maintainers                 | 70%                                                    | Not covered            |
| Restorative fillings              | 70%                                                    | 35%                    |
| Class 3                           |                                                        |                        |
| Oral Surgery                      | 70%                                                    | 50%                    |
| Endodontics                       | 70%                                                    | 50%                    |
| Periodontics                      | 70%                                                    | 50%                    |
| Restorative crowns                | 70%                                                    | 50%                    |
| Bridges                           | 70%                                                    | 50%                    |
| Partial and complete dentures     | 70%                                                    | 50%                    |
| Anesthesia                        | 70%                                                    | 50%                    |
| Orthodontia                       | 70%                                                    | Not covered            |
| Features                          |                                                        |                        |
| Provider Network                  | Delta Dental Premier Network                           |                        |
| Balance bill                      | Delta Dental Premier Network: No Nonparticipating: Yes |                        |
