| unnamed: 0                       | family coverage plans                              | unnamed: 2                                         | unnamed: 3                                         |
|----------------------------------|----------------------------------------------------|----------------------------------------------------|----------------------------------------------------|
|                                  | Family High Option                                 | Family Low Option                                  | Family Basic Option                                |
| One Child                        |                                                    |                                                    |                                                    |
| Two or More Children             |                                                    |                                                    |                                                    |
| Individual                       | $20.36                                             | $16.28                                             | $12.30                                             |
| Individual + Spouse              | $40.72                                             | $32.57                                             | $24.60                                             |
| Individual + Child(ren)          | $62.00                                             | $49.59                                             | $45.60                                             |
| Family                           | $91.20                                             | $72.94                                             | $64.97                                             |
|                                  | Family High Option                                 | Family Low Option                                  | Family Basic Option                                |
| Copay*                           |                                                    | $10                                                | $10                                                |
| Deductible*                      | $50 per covered individual $150 maximum per policy | $50 per covered individual $150 maximum per policy | $50 per covered individual $150 maximum per policy |
| Preventive Services*             | Plan pays 100%                                     | Plan pays 100%                                     | Plan pays 100%                                     |
| BasicServices*                   | Plan pays 80%                                      | Plan pays 50%                                      | Plan pays 50%                                      |
| Major Services*                  | Plan pays 50%                                      | Plan pays 50%                                      | Over age 19: 0%                                    |
| Medically Necessary Orthodontia* | Plan pays 50%                                      | Plan pays 50%                                      | Plan pays 50%                                      |
| Maximum Out-of-Pocket            | $350 one child $700 two or more children           | $350 one child $700 two or more children           | $350 one child $700 two or more children           |
| Annual Benefit Max (19 and over) | $1,000                                             | $1,000                                             | $1,000                                             |
