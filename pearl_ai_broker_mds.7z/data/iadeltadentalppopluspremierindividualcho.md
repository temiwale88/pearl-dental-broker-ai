| Typical
Services          | Without
Coverage         | With
Delta Dental
coverage
( after mo . premium )            |
|----------|---------|------------|
| Cleanings ,
X - rays          | $ 249   | $ 0        |
| Fillings | $ 234   | $ 117      |
| Root
Canals          | $ 1,090 | $ 545      |
| Eye Exam | $ 150   | $ 10 copay |
| Frames   | $ 180   | $ 40       |
| Contact
Lenses          | $ 275   | Balance
over $ 130            |
