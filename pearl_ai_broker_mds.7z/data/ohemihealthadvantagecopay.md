| Plan Summary                                                                | Advantage Network           | Out-of-Network      |
|-----------------------------------------------------------------------------|-----------------------------|---------------------|
| Services                                                                    |                             |                     |
| PreventiveOral Exams, Cleanings, Sealants, X-rays, Fluoride                 | 100%                        | See Co-Pay Schedule |
| BasicFillings, Space Maintainers, Oral Surgery                              | See Co-Pay Schedule         |                     |
| MajorCrowns, Bridges, Prosthodontics, Endodontics, Periodontics             |                             |                     |
| Orthodontics (up to age 19*)(Medically Necessary / Non-Medically Necessary) | 50% / Discount Only         | 50% / Not Covered   |
| Waiting Periods                                                             |                             |                     |
| Preventive                                                                  | None                        |                     |
| Basic (age 19 and older)                                                    | 6 Month Waiting Period      |                     |
| Major (age 19 and older)                                                    | 12 Month Waiting Period     |                     |
| Orthodontics(Medically Necessary / Non-Medically Necessary)                 | None / Not Applicable       |                     |
| Deductible (applies to Preventive, Basic and Major)                         |                             |                     |
| Individual                                                                  | $50                         |                     |
| Family Max                                                                  | $150                        |                     |
| Maximums                                                                    |                             |                     |
| Major Annual Max                                                            | No Maximum                  |                     |
| Annual Max per Person                                                       | No Maximum                  |                     |
| Orthodontic Lifetime Max(Medically Necessary / Non-Medically Necessary)     | No Maximum / Not Applicable |                     |
| Pediatric EHB Annual Max                                                    | No Maximum                  |                     |
| Pedriatric Individual EHB Out-of-Pocket Max                                 | $375                        |                     |
| Pediatric Family EHB Out-of-Pocket Max                                      | $750                        |                     |
