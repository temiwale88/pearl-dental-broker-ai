| PREFERRED     | LOW PLANS PAY   |
|---------------|-----------------|
| ADULT OR FAMILY
In - Network / Out - of - Network               | PEDIATRIC " EHB "
In - Network / Out - of - Network                 |
| $             | $               |
| 100 % / 100 % | 80 % / 80 %     |
| 100 % / 100 %
100 % / 100 %
Waiting Period : 6 Months               | 80 % / 80 %
80 % / 80 %                 |
| 60 % / 60 %
Waiting Period : 6 Months               | 60 % / 60 %     |
| 60 % / 60 %
Waiting Period : 12 Months               | 60 % / 60 %     |
| 30 % / 30 %
Waiting Period : 12 Months               | 50 % / 50 %     |
| Not Covered   | 50 % / 50 %     |
| $ 50 / $ 150  | $ 50 / $ 150    |
