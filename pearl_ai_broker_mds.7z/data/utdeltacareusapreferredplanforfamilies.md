| basic services   | unnamed: 1                                                             | unnamed: 2    | unnamed: 3                  | diagnostic and p preventive services   |
|------------------|------------------------------------------------------------------------|---------------|-----------------------------|----------------------------------------|
| D2140            | Amalgam (silver-colored) filling, 1 surface                            | Not a benefit | $14                         |                                        |
| D2150            | Amalgam (silver-colored) filling, 2 surfaces                           | Not a benefit | $25                         |                                        |
| D2160            | Amalgam (silver-colored) filling, 3 surfaces                           | Not a benefit | $30                         |                                        |
| D2330            | Resin (tooth-colored) filling, front tooth, 1                          | Not a benefit | $35                         |                                        |
| D2331            | surface Resin (tooth-colored) filling, front tooth, 2                  |               | $40                         |                                        |
| D2332            | surfaces Resin (tooth-colored) filling, front tooth, 3                 | Not a benefit |                             |                                        |
| D2391            | surfaces Resin (tooth-colored) filling, back tooth, 1                  | Not a benefit | $45                         |                                        |
| D2392            | surface Resin (tooth-colored) filling, back tooth, 2                   | Not a benefit | $40                         |                                        |
| D2393            | surfaces Resin (tooth-colored) filling, back tooth, 3                  | Not a benefit | $55                         |                                        |
|                  | surfaces                                                               | Not a benefit | $65                         |                                        |
| Endodontics      |                                                                        |               |                             |                                        |
| D3310            | Root canal, front tooth                                                | Not a benefit | $229                        |                                        |
| D3320            | Root canal, premolar tooth                                             | Not a benefit | $272                        |                                        |
| D3330            | Root canal, molar tooth                                                | Not a benefit | $371                        |                                        |
| Periodontics     |                                                                        |               |                             |                                        |
| D4260            | Periodontal surgery, per quadrant                                      | Not a benefit | $360                        |                                        |
| D4341            | Periodontal scaling and root planing - four or more teeth per quadrant | Not a benefit | $50                         |                                        |
| D4910            | Periodontal maintenance                                                | Not a benefit | $50                         |                                        |
| Oral Surgery     |                                                                        |               |                             |                                        |
| D7140            | Extraction (removal) of a fully exposed tooth                          | Not a benefit | $35                         |                                        |
| D7210            | Extraction of erupted (exposed) tooth                                  | Not a benefit | $35                         |                                        |
| D7240            | Extraction of fully impacted tooth, completely bony                    | Not a benefit | $125                        |                                        |
| Major Services   |                                                                        |               |                             |                                        |
| D2750            | Crown, porcelain and precious metal                                    | Not a benefit | $354                        |                                        |
| D2790            | Crown, precious metal                                                  | Not a benefit | $354                        |                                        |
| D5110            | Full upper denture                                                     | Not a benefit | $510                        |                                        |
| D6240            | Bridge pontic, porcelain and precious metal                            | Not a benefit | $354                        |                                        |
| D6750            | Bridge crown, porcelain and precious metal                             | Not a benefit | $354                        |                                        |
| Orthodontics     |                                                                        |               |                             |                                        |
| D8090            | Adult services                                                         | Not a benefit | $3,250                      |                                        |
|                  | Office visit                                                           | No cost       | $5                          | D0999                                  |
|                  | Periodic oral exam - established patient                               | $5            | $5                          | D0120                                  |
|                  | Comprehensive oral evaluation - new or established patient             | $5            | $5                          | D0150                                  |
|                  | Complete series of x-rays Periapical x-ray of tooth's root             | $5 $5         | $5 $5                       | D0210 D0220                            |
|                  | Periapical x-ray of tooth's root, each additional image                | $5            | $5                          | D0230                                  |
|                  | Bitewing x-rays (2 images)                                             | $5            | $5                          | D0272                                  |
|                  | Bitewing x-rays (4 images)                                             | $5            | $5                          | D0274                                  |
|                  | Panoramic x-ray                                                        | $5            | $5                          | D0330                                  |
|                  | Prophylaxis (cleaning) — adult                                         | $5            | $5                          | D1110                                  |
|                  | Prophylaxis (cleaning) － child Fluoride treatment                     | $5 $5         | Not a benefit Not a benefit | D1120 D1208                            |
|                  | Sealant — per tooth                                                    | $5            | Not a benefit               | D1351                                  |
