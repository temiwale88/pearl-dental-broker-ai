| Annual deductible   | Adult   | Family   | Pediatric   |
|---------------------|---------|----------|-------------|
| This is the amount you will pay out - of - pocket for basic
services in the plan ( excludes discount services ) 2                     | $ 35    | $ 35 per adult
$ 35 per child          | $ 35        |
| Annual maximum
This is the maximum amount that the plan will pay during
the calendar year ( excludes discount services ) 2                     | $ 1,000 | $ 1,000
per individual adult
family member          | No annual
maximum             |
