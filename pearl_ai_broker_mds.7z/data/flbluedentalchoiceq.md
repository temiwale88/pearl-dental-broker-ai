| bluedental choice q                                           | in-network you pay       | out-of-network you pay   |
|---------------------------------------------------------------|--------------------------|--------------------------|
| PEDIATRIC BENEFITS (to age 19)                                |                          |                          |
| Deductible (applies to only basic and major services)         | $50                      |                          |
| Out-of-pocket maximum if only one child is covered            | $375                     | Unlimited                |
| Out-of-pocket maximum if more than one child is covered       | $750                     | Unlimited                |
| Preventive Services                                           | NO WAITING PERIOD        |                          |
| Oral exams                                                    | 0%                       | 20%                      |
| Cleanings                                                     | 0%                       | 20%                      |
| Bitewing x-rays                                               | 0%                       | 20%                      |
| Fluoride treatment                                            | 0%                       | 20%                      |
| Sealant - per tooth                                           | 0%                       | 20%                      |
| Basic Services                                                | NO WAITING PERIOD        |                          |
| Fillings                                                      | 20%                      | 40%                      |
| Emergency treatment of dental pain                            | 20%                      | 40%                      |
| Extraction - erupted tooth or exposed root                    | 20%                      | 40%                      |
| Major Services                                                | NO WAITING PERIOD        |                          |
| Crowns                                                        | 50%                      | 70%                      |
| Root canals                                                   | 50%                      | 70%                      |
| Dentures                                                      | 50%                      | 70%                      |
| Partials                                                      | 50%                      | 70%                      |
| Medically necessary implants (pre-authorization required)     | 50%                      | 70%                      |
| Medically necessary orthodontics (pre-authorization required) | 50%                      | 70%                      |
| Additional Benefit Programs                                   |                          |                          |
| Oral Health for Overall Health                                | Included                 |                          |
| TeleDentistry.com benefit                                     | 2 consultations per year |                          |
