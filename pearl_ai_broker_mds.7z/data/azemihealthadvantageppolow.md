|                                                                         | Children age up to 19**     | Adults age 19 and older   | None              | None            |
|-------------------------------------------------------------------------|-----------------------------|---------------------------|-------------------|-----------------|
| Plan Summary                                                            | Advantage Network           | Out-of-Network            | Advantage Network | Out-of-Network  |
| Services                                                                |                             |                           |                   |                 |
| PreventiveOral Exams, Cleanings, Sealants, X-rays, Fluoride             | 100%                        | 100% up to MAC*           | 100%              | 100% up to MAC* |
| BasicFillings, Space Maintainers, Oral Surgery                          | 50%                         | 50% up to MAC*            | 50%               | 50% up to MAC*  |
| MajorCrowns, Bridges, Prosthodontics, Endodontics, Periodontics         | 25%                         | 25% up to MAC*            | Not Covered       | Not Covered     |
| Orthodontics(Medically Necessary / Non-Medically Necessary)             | 50% / Not Covered           | 50% / Not Covered         | Not Covered       | Not Covered     |
| Waiting Periods                                                         |                             |                           |                   |                 |
| Preventive                                                              | None                        |                           |                   |                 |
| Basic (age 19 and older)                                                | 6 Month Waiting Period      |                           |                   |                 |
| Major                                                                   | None                        |                           |                   |                 |
| Orthodontics(Medically Necessary / Non-Medically Necessary)             | None / Not Applicable       |                           |                   |                 |
| Deductible (applies to Preventive, Basic and Major)                     |                             |                           |                   |                 |
| Individual                                                              | $75.00                      |                           |                   |                 |
| Family Max                                                              | $225.00                     |                           |                   |                 |
| Maximums                                                                |                             |                           |                   |                 |
| Major Annual Max (age 19 and older)                                     | No Maximum                  |                           |                   |                 |
| Annual Max per Person (age 19 and older)                                | $1,000                      |                           |                   |                 |
| Orthodontic Lifetime Max(Medically Necessary / Non-Medically Necessary) | No Maximum / Not Applicable |                           |                   |                 |
| Pediatric EHB Annual Max                                                | No Maximum                  | Not Applicable            |                   |                 |
| Pedriatric Individual EHB Out-of-Pocket Max                             | $375                        | Not Applicable            |                   |                 |
| Pediatric Family EHB Out-of-Pocket Max                                  | $750                        | Not Applicable            |                   |                 |
