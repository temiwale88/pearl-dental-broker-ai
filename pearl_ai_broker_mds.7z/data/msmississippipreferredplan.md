| OUR RENAISSANCE DENTAL BENEFIT SELECTION GUIDE :                                               | SELECTED                  | PLAN         |
|------------------------------------------------------------------------------------------------|---------------------------|--------------|
| HE SIDE BY SIDE DENTAL BENEFIT COMPARISONS BELOW HELP GUIDE
OU IN SELECTING A PLAN THAT IS RIGHT FOR YOU AND YOUR FAMILY .                                                                                                | PREFERRED LOW             | PLANS PAY    |
| OTES : ADULTS DEFINED AS AGE 219 AND CHILDREN DEFINED AS AGE < 19 .
THE MOST RECENT RATE FOR THIS PLAN CAN BE CONFIRMED AT HEALTHCARE.GOV .                                                                                                | ADULT OR FAMILY
In - Network / Out - of - Network                           | PEDIATRIC " EHB "
In - Network / Out - of - Network              |
| ADD YOUR MARKET PLACE QUOTES IN THE ROWS TO THE RIGHT . *                                      | $                         | $            |
| Diagnostic & Preventive Services - exams , cleanings , bitewing x - rays & fluoride treatments | 100 % / 100 %             | 80 % / 80 %  |
| Basic Services                                                                                 | 100 % / 100 %             | 80 % / 80 %  |
| Emergency Palliative Treatment - to temporarily relieve pain                                   |                           |              |
| Sealants - to prevent decay of permanent teeth                                                 | 100 % / 100 %             | 80% / 80%    |
| Radiographs - all other X - rays                                                               | Waiting Period : 6 Months |              |
| Minor Restorative Services - fillings and crown repair                                         |                           |              |
| Simple Extractions - non - surgical extractions                                                | 60 % / 60 %               | 60 % / 60 %  |
| Periodontal Maintenance - following active periodontal therapy                                 | Waiting Period : 6 Months |              |
| Other Basic Services - miscellaneous services                                                  |                           |              |
| Major Services                                                                                 |                           |              |
| Oral Surgery Services - extractions and dental surgery                                         |                           |              |
| Endodontic Services - root canals                                                              | 60 % / 60 %
Waiting Period : 12 Months                           | 60 % / 60 %  |
| Periodontic Services - to treat gum disease                                                    |                           |              |
| Relines and Repairs - to bridges and dentures                                                  |                           |              |
| Prosthodontic Services - bridges , implants and dentures                                       |                           |              |
| Major Restorative Services - crowns                                                            | 30 % / 30 %
Waiting Period : 12 Months                           | 50 % / 50 %  |
| Other Major Services - miscellaneous services                                                  |                           |              |
| Orthodontics - medically necessary services / treatment ( for example braces ) until age 19    | Not Covered               | 50 % / 50 %  |
| Benefit Year Deductible - per person / per family . ( deductible does not apply to all services , for list of services
please refer to the additional plan information )                                                                                                | $ 50 / $ 150              | $ 50 / $ 150 |
