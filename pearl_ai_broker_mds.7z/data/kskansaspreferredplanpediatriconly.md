|                                                                                                |    |                           |               |
|------------------------------------------------------------------------------------------------|----|---------------------------|---------------|
| THE SIDE BY SIDE DENTAL BENEFIT COMPARISONS BELOW HELP GUIDE
YOU IN SELECTING A PLAN THAT IS RIGHT FOR YOU AND YOUR FAMILY .                                                                                                |    | PREFERRED                 | LOW PLANS PAY |
| NOTES : ADULTS DEFINED AS AGE 19 AND CHILDREN DEFINED AS AGE < 19 .
* THE MOST RECENT RATE FOR THIS PLAN CAN BE CONFIRMED AT HEALTHCARE.GOV .                                                                                                |    | ADULT OR FAMILY
In - Network / Out - of - Network                           | PEDIATRIC " EHB "
In - Network / Out - of - Network               |
| ADD YOUR MARKET PLACE QUOTES IN THE ROWS TO THE RIGHT . *                                      |    | $                         | $             |
| Diagnostic & Preventive Services - exams , cleanings , bitewing x - rays & fluoride treatments |    | 100 % / 70 %              | 80 % / 70 %   |
| Basic Services
Emergency Palliative Treatment - to temporarily relieve pain                                                                                                |    | 100 % / 70 %              | 80 % / 70 %   |
| Sealants to prevent decay of permanent teeth
Radiographs - all other X - rays                                                                                                |    | 100 % / 70 %
Waiting Period : 6 Months                           | 80 % / 70 %   |
| Minor Restorative Services - fillings and crown repair                                         |    |                           |               |
| Simple Extractions - non - surgical extractions                                                |    | 60 % / 40 %               | 60 % / 50 %   |
| Periodontal Maintenance - following active periodontal therapy                                 |    | Waiting Period : 6 Months |               |
| Other Basic Services - miscellaneous services                                                  |    |                           |               |
| Major Services                                                                                 |    |                           |               |
| Oral Surgery Services - extractions and dental surgery                                         |    |                           |               |
| Endodontic Services - root canals                                                              |    | 60 % / 40 %
Waiting Period : 12 Months                           | 60 % / 50 %   |
| Periodontic Services - to treat gum disease                                                    |    |                           |               |
| Relines and Repairs - to bridges and dentures                                                  |    |                           |               |
| Prosthodontic Services - bridges , implants and dentures
Major Restorative Services - crowns
Other Major Services - miscellaneous services                                                                                                |    | 50 % / 30 %
Waiting Period : 12 Months                           | 50 % / 50 %   |
| Orthodontics - medically necessary services / treatment ( for example braces ) until age 19    |    | Not Covered               | 50 % / 50 %   |
| Benefit Year Deductible - per person / per family . ( deductible does not apply to all services , for list of
services please refer to the additional plan information )                                                                                                |    | $ 50 / $ 150              | $ 50 / $ 150  |
