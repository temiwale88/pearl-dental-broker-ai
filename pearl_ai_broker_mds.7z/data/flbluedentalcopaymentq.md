| bluedental copayment q                                                                 |
|----------------------------------------------------------------------------------------|
| PEDIATRIC BENEFITS (to age 19)4                                                        |
| Deductible (applies to preventive, basic, and major services)                          |
| Out-of-pocket maximum if only one child is covered $375                                |
| Out-of-pocket maximum if more than one child is covered $750                           |
| Preventive Services NO WAITING PERIOD 20%                                              |
| Oral exams $O                                                                          |
| Cleanings $O 20%                                                                       |
| Bitewing x-rays $O 20%                                                                 |
| Fluoride treatment $O 20%                                                              |
| Sealant (per tooth) $6 20%                                                             |
| Basic Services NO WAITING PERIOD                                                       |
| Amalgam restorations (one surface, primary/permanent) $15 40%                          |
| Resin-based composite (one surface, front tooth) $20 40%                               |
| Emergency treatment of dental pain $12 40%                                             |
| Extraction (erupted tooth or exposed root) $17 40%                                     |
| Major Services NO WAITING PERIOD                                                       |
| Crown (porcelain fused to noble metal) $302 60%                                        |
| Root canal molar $305 60%                                                              |
| Complete denture (upper) $375 60%                                                      |
| Upper partial (resin-based) $296 60%                                                   |
| Medically necessary implants (pre-authorization required)                              |
| Surgical placement of implant body (endosteal implant) $375 70%                        |
| Implant supported porcelain fused to metal crown (titanium, high noble metal) $282 70% |
| Medically necessary orthodontics (pre-authorization required) $375 70%                 |
| Additional Benefit Programs                                                            |
