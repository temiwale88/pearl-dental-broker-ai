| DENTAL BENEFIT                            | CIGNA DPPO
ADVANTAGE
NETWORK                  | OUT - OF
NETWORK *
Out - of - pocket expenses
may be higher ; these
providers do not offer
Cigna customers
our contracted
or discounted fees .                    | CIGNA DPPO
ADVANTAGE
NETWORK           | OUT - OF
NETWORK *
Out - of - pocket expenses
may be higher ; these
providers do not
offer Cigna
our contracted
or discounted fees .
customers            |
|-------------------------------------------|------------------|--------------------|-----------|------------|
| Individual Calendar - Year Deductible     | $ 150 per        | person             | $ 50 per  | person     |
| Family Calendar - Year Deductible         | $ 300 per        | family             | $ 150 per | family     |
| Calendar - Year Out - of - Pocket Maximum | $ 375 per person | / $ 750 per family | Not       | applicable |
| Calendar - Year Maximum                   | Not              | applicable         | $ 1,000   | per person |
| Payment Levels                            | Based on provider's
contracted fees for
covered services                  | Based on provider's
actual billed charges
and the contracted fee                    | Based on provider's
contracted fees for
covered services           | Based on provider's
actual billed charges
and the contracted fee            |
|                                           |                  |                    |           |            |
