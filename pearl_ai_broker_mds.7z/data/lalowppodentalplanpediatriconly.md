| CERTIFIED HIGH   | PLANS PAY     |    | CERTIFIED    | LOW PLANS PAY   |
|------------------|---------------|----|--------------|-----------------|
| ADULT OR FAMILY
In - Network / Out - of - Network                  | PEDIATRIC " EHB "
In - Network / Out - of - Network               |    | ADULT OR FAMILY
In - Network / Out - of - Network              | PEDIATRIC " EHB "
In - Network / Out - of - Network                 |
| $                | $             |    | $            | $               |
| 100 % / 100 %    | 100 % / 100 % |    | 80 % / 80 %  | 80 % / 80 %     |
| 100 % / 100 %    | 100 % / 100 % |    | 80 % / 80 %  | 80 % / 80 %     |
| 100 % / 100 %    | 100 % / 100 % |    | 80 % / 80 %
Waiting Period : 6 Months              | 80 % / 80 %     |
| 70 % / 70 %
Waiting Period : 6 Months                  | 70 % / 70 %   |    | 60 % / 60 %
Waiting Period : 6 Months              | 60 % / 60 %     |
| 70 % / 70 %
Waiting Period : 12 Months                  | 70 % 70 %     |    | 60 % / 60 %
Waiting Period : 12 Months              | 60 % / 60 %     |
| 50 % / 0 %
Waiting Period : 12 Months                  | 50 % / 50 %   |    | 50 % / 50 %
Waiting Period : 12 Months              | 50 % / 50 %     |
| Not Covered      | 50 % / 50 %   |    | Not Covered  | 50 % / 50 %     |
| $ 50 / $ 150     | $ 50 / $ 150  |    | $ 50 / $ 150 | $ 50 / $ 150    |
