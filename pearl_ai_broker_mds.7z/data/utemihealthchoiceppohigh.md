| Plan Summary                                                    | Advantage Network                              | Premier Network   | Out-of-Network   |
|-----------------------------------------------------------------|------------------------------------------------|-------------------|------------------|
| Services                                                        |                                                |                   |                  |
| PreventiveOral Exams, Cleanings, Sealants, X-rays, Fluoride     | 100%                                           | 100%              | 100% up to MAC*  |
| BasicFillings, Space Maintainers, Oral Surgery                  | 80%                                            | 80%               | 80% up to MAC*   |
| MajorCrowns, Bridges, Prosthodontics, Endodontics, Periodontics | 50%                                            | 50%               | 50% up to MAC*   |
| OrthodonticsChildren (age 7 through 18)                         | 50%                                            | 50%               | 50%              |
| Adults                                                          | Discount Only                                  | Discount Only     | No Coverage      |
| Waiting Periods                                                 |                                                |                   |                  |
| Preventive                                                      | None                                           |                   |                  |
| Basic                                                           | 6 Month Waiting Period                         |                   |                  |
| Major                                                           | 15 Month Waiting Period                        |                   |                  |
| Orthodontics                                                    | 24 Month Waiting Period                        |                   |                  |
| Deductible (applies to Preventive, Basic and Major)             | In and Out of Network Deductibles are Combined |                   |                  |
| Individual                                                      | $25                                            | $50               | $50              |
| Family Max                                                      | $75                                            | $150              | $150             |
| Maximums                                                        |                                                |                   |                  |
| Major Annual Max†                                               | $750                                           |                   |                  |
| Annual Max per Person†                                          | $1,500                                         | $1,000            |                  |
| Orthodontic Lifetime Max                                        | $1,000                                         |                   |                  |
| Pediatric EHB Annual Max                                        | No Maximum                                     |                   |                  |
| Pedriatric Individual EHB Out-of-Pocket Max                     | $375                                           |                   |                  |
| Pediatric Family EHB Out-of-Pocket Max                          | $750                                           |                   |                  |
