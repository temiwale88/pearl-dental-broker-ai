|                                                                                                |    |                           |                |                           |              |
|------------------------------------------------------------------------------------------------|----|---------------------------|----------------|---------------------------|--------------|
| THE SIDE BY SIDE DENTAL BENEFIT COMPARISONS BELOW HELP GUIDE
YOU IN SELECTING A PLAN THAT IS RIGHT FOR YOU AND YOUR FAMILY .                                                                                                |    | CERTIFIED                 | HIGH PLANS PAY | CERTIFIED LOW             | PLANS PAY    |
| NOTES : ADULTS DEFINED AS AGE > 19 AND CHILDREN DEFINED AS AGE < 19 .
* THE MOST RECENT RATE FOR THIS PLAN CAN BE CONFIRMED AT HEALTHCARE.GOV .                                                                                                |    | ADULT OR FAMILY
In - Network / Out - of - Network                           | PEDIATRIC " EHB "
In - Network / Out - of - Network                | ADULT OR FAMILY
In - Network / Out - of - Network                           | PEDIATRIC " EHB "
In - Network / Out - of - Network              |
| ADD YOUR MARKET PLACE QUOTES IN THE ROWS TO THE RIGHT . *                                      |    | $                         | $              | $                         | $            |
| Diagnostic & Preventive Services - exams , cleanings , bitewing x - rays & fluoride treatments |    | 100 % / 80 %              | 100 % / 80 %   | 100 % / 70 %              | 100 % / 70 % |
| Basic Services
Emergency Palliative Treatment - to temporarily relieve pain                                                                                                |    | 100 % / 80 %              | 100 % / 80 %   | 100 % / 70 %              | 100 % / 70 % |
| Sealants to prevent decay of permanent teeth
Radiographs - all other X - rays                                                                                                |    | 100 % / 80 %              | 100 % / 80 %   | 100 % / 70 %
Waiting Period : 6 Months                           | 100 % / 70 % |
| Minor Restorative Services - fillings and crown repair                                         |    |                           |                |                           |              |
| Simple Extractions - non - surgical extractions                                                |    | 75 % / 60 %               | 75 % / 60 %    | 60 % / 40 %               | 60 % / 40 %  |
| Periodontal Maintenance - following active periodontal therapy                                 |    | Waiting Period : 6 Months |                | Waiting Period : 6 Months |              |
| Other Basic Services - miscellaneous services                                                  |    |                           |                |                           |              |
| Major Services                                                                                 |    |                           |                |                           |              |
| Oral Surgery Services - extractions and dental surgery                                         |    |                           |                |                           |              |
| Endodontic Services - root canals                                                              |    | 75 % / 60 %
Waiting Period : 12 Months                           | 75 % / 60 %    | 60 % / 40 %
Waiting Period : 12 Months                           | 60 % / 40 %  |
| Periodontic Services - to treat gum disease                                                    |    |                           |                |                           |              |
| Relines and Repairs - to bridges and dentures                                                  |    |                           |                |                           |              |
| Prosthodontic Services - bridges , implants and dentures                                       |    |                           |                |                           |              |
| Major Restorative Services - crowns                                                            |    | 50 % / 40 %
Waiting Period : 12 Months                           | 50 % / 40 %    | 50 % / 30 %
Waiting Period : 12 Months                           | 50 % / 30 %  |
| Other Major Services - miscellaneous services                                                  |    |                           |                |                           |              |
| Orthodontics - medically necessary services / treatment ( for example braces ) until age 19    |    | Not Covered               | 50 % / 50 %    | Not Covered               | 50 % / 50 %  |
| Benefit Year Deductible - per person / per family . ( deductible does not apply to all services , for list
of services please refer to the additional plan information )                                                                                                |    | $ 50 / $ 150              | $ 50 / $ 150   | $ 50 / $ 150              | $ 50 / $ 150 |
